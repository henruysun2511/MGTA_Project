export const EVENT = {
  NEW_SCHEDULE: 'new_schedule',
  CHANGE_CLASS: 'change_class',
  ASSIGN_EXERCISE: 'assign_exercise',
  JOIN_CLASS: 'join_class',
  ADD_TO_CLASS: 'add_to_class',
  CHANGE_CLASS_SCHEDULE: 'change_class_schedule',
  UPDATE_CLASS: 'update_class'
};