import { combineReducers } from "redux";
import { baseReducer } from "../reducers/baseReducer";
import loginReducer from "../reducers/loginReducer";


const AllReducers = combineReducers({
    loginReducer, 
    classschedules: baseReducer("classschedules"),
    classes: baseReducer("classes"),
    classsessions: baseReducer("classsessions"),
    students: baseReducer("students"),
    deadlines: baseReducer("deadlines"),
    exercises: baseReducer("exercises"),
    accounts: baseReducer("accounts"),
    skills: baseReducer("skills"),
    blogs: baseReducer("blogs"),
    results: baseReducer("results"),
    notifications: baseReducer("notifications"),
    comments: baseReducer("comments"),
    roles: baseReducer("roles"),
    permissions: baseReducer("permissions"),
    deletedblogs: baseReducer("deletedblogs"),
    deletedaccounts: baseReducer("deletedaccounts"),
    settings: baseReducer("settings"),
    replycomments: baseReducer("replycomments")
});

export default AllReducers;