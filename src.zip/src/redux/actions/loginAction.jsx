export const checkLogin = (status) => {
    return {
        type: 'CHECK_LOGIN',
        payload: status
    }
}