import Container from "../../../../components/Container/index";
export default function Section1() {
    return (<>
        <div class="blog__section-1">
            <Container>
                <div class="blog__title">
                    <h1>BLOG HỌC TẬP</h1>
                    <p>Nơi khơi dậy niềm yêu thích Tiếng Anh, cung cấp tài liệu học tập và phương pháp học tập cho tất cả các bạn học sinh
                    </p>
                </div>
            </Container>
        </div>

    </>)
}